<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hotel Casa Sur</title>
</head>

<body>
<?
$destino="reservas@casasur.pe";

$nombre= $_POST["nombre"];
$mail= $_POST["email"];
$fono= $_POST["fono"];
$direccion= $_POST["direccion"];
$habitacion= $_POST["habitacion"];
$num_hab= $_POST["num_hab"];
$num_pers= $_POST["num_pers"];
$fecha_ingreso= $_POST["fecha_ingreso"];
$fecha_salida=$_POST["fecha_salida"];
$mensaje= $_POST["mensaje"];
$contenido="Nombre: " . $nombre . "\n
Correo: " . $mail . "\n
Teléfono: " . $fono . "\n
Dirección: " . $direccion . "\n
Habitación: " . $habitacion . "\n
N° de Habitación: " . $num_hab . "\n
N° de Personas: " . $num_pers . "\n
Fecha de Ingreso: " .$fecha_ingreso . "\n
Fecha de Salida: " .$fecha_salida . "\n

Comentario: " . $mensaje;

mail($destino, "Contacto desde Casa Sur", $contenido);
print "<meta http-equiv=Refresh content=\"2 ; url=gracias.html\">";
?>
</body>
</html>